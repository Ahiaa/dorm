package com.example.liekai.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.liekai.pojo.studentt;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

@Mapper
public interface StudentMapper extends BaseMapper<studentt> {

    // 根据学号查询学生
    @Select("SELECT * FROM student WHERE student_id = #{studentId}")
    studentt selectByStudentId(String studentId);
}
