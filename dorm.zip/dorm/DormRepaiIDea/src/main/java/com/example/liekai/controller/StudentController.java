package com.example.liekai.controller;


import com.example.liekai.pojo.Result;
import com.example.liekai.pojo.studentt;
import com.example.liekai.service.StudentService;
import com.example.liekai.utils.JwtUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/student")
public class StudentController {

    @Autowired
    private StudentService studentService;

    @PostMapping("/register")
    public Result register(@RequestBody studentt student) {
        if (!studentService.isStudentIdAvailable(student.getStudentId())) {
            return Result.error("学号已被注册");
        }

        boolean success = studentService.register(student);
        if (success) {
            return Result.success();
        } else {
            return Result.error("注册失败");
        }
    }

    @PostMapping("/login")
    public Result login(
            @RequestParam String studentId,
            @RequestParam String password) {

        // 验证学生登录
        studentt student = studentService.login(studentId, password);
        if (student != null) {
            /*
             * 登录成功，生成并下发JWT令牌
             */
            Map<String, Object> claims = new HashMap<>();
            claims.put("studentId", student.getStudentId());
            claims.put("role", "student"); // 添加角色标识

            String jwt = JwtUtils.generateJwt(claims);
            return Result.success(jwt);
        } else {
            return Result.error("用户名或密码错误");
        }
    }

    @GetMapping("/check-id")
    public Result checkStudentId(@RequestParam String studentId) {
        boolean available = studentService.isStudentIdAvailable(studentId);
        return Result.success(Map.of("available", available));
    }
}
