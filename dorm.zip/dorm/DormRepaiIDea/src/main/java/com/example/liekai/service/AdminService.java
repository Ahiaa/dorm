package com.example.liekai.service;


import com.example.liekai.pojo.Admin;

public interface AdminService {

    Admin login(String adminId, String password);
}

