package com.example.liekai.service;

public interface AnnouncementService {
}
