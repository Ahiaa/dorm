package com.example.liekai.controller;


import com.example.liekai.pojo.Repairman;
import com.example.liekai.pojo.Result;
import com.example.liekai.service.RepairmanService;
import com.example.liekai.utils.JwtUtils;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/repairman")
public class RepairmanController {

    @Autowired
    private RepairmanService repairmanService;

    @PostMapping("/login")
    public Result login(
            @RequestParam String repairmanId,
            @RequestParam String password,
            @RequestParam String captcha,
            HttpSession session) {

        // 验证验证码
        String sessionCaptcha = (String) session.getAttribute("captcha");
        if (sessionCaptcha == null || !sessionCaptcha.equalsIgnoreCase(captcha)) {
            return Result.error("验证码错误");
        }

        // 验证维修人员登录
        Repairman repairman = repairmanService.login(repairmanId, password);
        if (repairman != null) {
            /*
             * 登录成功，生成并下发JWT令牌
             */
            Map<String, Object> claims = new HashMap<>();
            claims.put("RepairmanId", repairman.getRepairmanId());
            claims.put("role", "Repairman"); // 添加角色标识

            String jwt = JwtUtils.generateJwt(claims);

            // 直接返回维修人员对象，让前端决定需要哪些字段
            return Result.success(repairman);
        } else {
            return Result.error("维修人员工号或密码错误");
        }
    }
}
