package com.example.liekai.controller;


import com.example.liekai.pojo.Admin;
import com.example.liekai.pojo.Result;
import com.example.liekai.service.AdminService;
import com.example.liekai.utils.JwtUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/admin")
public class AdminController {

    @Autowired
    private AdminService adminService;

    @PostMapping("/login")
    public Result login(
            @RequestParam String adminId,
            @RequestParam String password
           ) {

        // 验证管理员登录
        Admin admin = adminService.login(adminId, password);
        if (admin != null) {
            /*
             * 登录成功，生成并下发JWT令牌
             */
            Map<String, Object> claims = new HashMap<>();
            claims.put("adminId", admin.getAdminId());
            claims.put("role", "admin"); // 添加角色标识
            String jwt = JwtUtils.generateJwt(claims);
            return Result.success(jwt);
        } else {
            return Result.error("管理员账号或密码错误");
        }
    }
}
