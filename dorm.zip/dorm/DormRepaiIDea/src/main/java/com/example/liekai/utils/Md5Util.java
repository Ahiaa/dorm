package com.example.liekai.utils;

import org.apache.commons.codec.digest.DigestUtils;

public class Md5Util {
    public static String encode(String text) {
        return DigestUtils.md5Hex(text);
    }
}
