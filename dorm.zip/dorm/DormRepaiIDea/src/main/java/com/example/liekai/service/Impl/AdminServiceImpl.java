package com.example.liekai.service.Impl;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.example.liekai.mapper.AdminMapper;
import com.example.liekai.pojo.Admin;
import com.example.liekai.service.AdminService;
import com.example.liekai.utils.Md5Util;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AdminServiceImpl implements AdminService {

    private final AdminMapper adminMapper;

    @Autowired
    public AdminServiceImpl(AdminMapper adminMapper) {
        this.adminMapper = adminMapper;
    }

    @Override
    public Admin login(String adminId, String password) {
        String encryptedPassword = Md5Util.encode(password);
        QueryWrapper<Admin> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("admin_id", adminId)
                .eq("password", encryptedPassword);
        return adminMapper.selectOne(queryWrapper);
    }
}

