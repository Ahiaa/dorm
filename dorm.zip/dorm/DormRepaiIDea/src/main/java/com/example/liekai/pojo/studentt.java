package com.example.liekai.pojo;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@TableName("student")
public class studentt {
    @TableId(value = "student_id")
    private String studentId; // 学号
    private String name;
    private String phone;
    @TableField(value = "building_id")
    private int buildingId;
    @TableField(value = "dorm_number")
    private String dormNumber;
    private String password; // MD5加密后的密码
    @TableField(value = "created_at")
    private LocalDateTime createdAt;
}
