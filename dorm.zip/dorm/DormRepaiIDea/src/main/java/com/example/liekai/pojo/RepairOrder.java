package com.example.liekai.pojo;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@TableName("repair_order")
public class RepairOrder {
    @TableId(value = "order_id", type = IdType.AUTO)
    private Long orderId; // 工单ID

    @TableField("student_id")
    private String studentId; // 报修学生ID

    @TableField("problem_summary")
    private String problemSummary; // 问题简述

    @TableField("problem_detail")
    private String problemDetail; // 问题详情

    @TableField("image_url")
    private String imageUrl; // 报修图片存储路径

    private String status; // 工单状态：报修, 修理中, 已修理, 已评价

    private String urgency; // 紧急程度：一般, 紧急, 危险

    @TableField("report_time")
    private LocalDateTime reportTime; // 报修时间

    @TableField("repair_time")
    private LocalDateTime repairTime; // 维修完成时间

    private Integer rating; // 服务评分(1-5)

    private String feedback; // 用户反馈

    @TableField("repairman_id")
    private String repairmanId; // 维修人员ID
}
