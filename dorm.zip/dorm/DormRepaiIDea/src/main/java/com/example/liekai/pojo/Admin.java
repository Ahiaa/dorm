package com.example.liekai.pojo;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@TableName("admin")
public class Admin {
    @TableId(type = IdType.INPUT, value = "admin_id") // 指定数据库字段名
    private String adminId; // 管理员ID
    private String password; // 密码
    @TableField(value = "created_at")
    private LocalDateTime createdAt;
}

