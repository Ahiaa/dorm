package com.example.liekai.pojo;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@TableName("notification")
public class Notification {
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    @TableField("user_id")
    private String userId; // 接收用户ID

    @TableField("user_type")
    private String userType; // 用户类型：student, admin

    private String title; // 通知标题

    private String content; // 通知内容

    @TableField("related_order")
    private Long relatedOrder; // 关联工单

    @TableField("send_time")
    private LocalDateTime sendTime; // 发送时间

    @TableField("is_read")
    private Boolean isRead; // 是否已读
}
