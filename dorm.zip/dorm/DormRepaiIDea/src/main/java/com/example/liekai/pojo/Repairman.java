package com.example.liekai.pojo;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.time.LocalDateTime;


@Data
@TableName("repairman")
public class Repairman {
    @TableId(value = "repairman_id")
    private String repairmanId; // 学号
    private String name;
    private String phone;
    private String specialty;
    @TableField(value = "is_active")
    private int isActive;
    private String password; // MD5加密后的密码
    @TableField(value = "created_at")
    private LocalDateTime createdAt;
}
