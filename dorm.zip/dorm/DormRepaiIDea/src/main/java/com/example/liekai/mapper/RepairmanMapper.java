package com.example.liekai.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.liekai.pojo.Repairman;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

;

@Mapper
public interface RepairmanMapper extends BaseMapper<Repairman> {

    // 根据维修工ID查找维修人员
    @Select("SELECT * FROM repairman WHERE repairman_id = #{repairmanId}")
    Repairman findById(String repairmanId);
}
