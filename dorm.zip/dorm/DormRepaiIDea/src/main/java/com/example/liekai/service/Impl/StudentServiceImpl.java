package com.example.liekai.service.Impl;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.example.liekai.mapper.StudentMapper;
import com.example.liekai.pojo.studentt;
import com.example.liekai.service.StudentService;
import com.example.liekai.utils.Md5Util;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

@Service
public class StudentServiceImpl implements StudentService {

    private final StudentMapper studentMapper;

    @Autowired
    public StudentServiceImpl(StudentMapper studentMapper) {
        this.studentMapper = studentMapper;
    }

    @Override
    @Transactional
    public boolean register(studentt student) {
        student.setPassword(Md5Util.encode(student.getPassword()));
        student.setCreatedAt(LocalDateTime.now());
        return studentMapper.insert(student) > 0;
    }

    @Override
    public studentt login(String studentId, String password) {
        String encryptedPassword = Md5Util.encode(password);
        QueryWrapper<studentt> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("student_id", studentId)
                .eq("password", encryptedPassword);
        return studentMapper.selectOne(queryWrapper);
    }

    @Override
    public boolean isStudentIdAvailable(String studentId) {
        QueryWrapper<studentt> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("student_id", studentId);
        return studentMapper.selectCount(queryWrapper) == 0;
    }
}

