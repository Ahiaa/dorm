package com.example.liekai.service.Impl;

public class DormBuildingImplService {
}
