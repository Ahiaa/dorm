package com.example.liekai.pojo;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@TableName("announcement")
public class Announcement {
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    private String title; // 公告标题

    private String content; // 公告内容

    @TableField("publisher_id")
    private String publisherId; // 发布者ID

    @TableField("publish_time")
    private LocalDateTime publishTime; // 发布时间

    @TableField("expire_time")
    private LocalDateTime expireTime; // 过期时间
}
