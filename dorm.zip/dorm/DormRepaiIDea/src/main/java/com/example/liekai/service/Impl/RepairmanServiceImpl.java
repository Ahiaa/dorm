package com.example.liekai.service.Impl;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.example.liekai.mapper.RepairmanMapper;
import com.example.liekai.pojo.Repairman;
import com.example.liekai.service.RepairmanService;
import com.example.liekai.utils.Md5Util;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class RepairmanServiceImpl implements RepairmanService {

    private final RepairmanMapper repairmanMapper;

    @Autowired
    public RepairmanServiceImpl(RepairmanMapper repairmanMapper) {
        this.repairmanMapper = repairmanMapper;
    }

    @Override
    public Repairman login(String repairmanId, String password) {
        String encryptedPassword = Md5Util.encode(password);
        QueryWrapper<Repairman> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("repairman_id", repairmanId)
                .eq("password", encryptedPassword)
                .eq("is_active", true);
        return repairmanMapper.selectOne(queryWrapper);
    }
}

