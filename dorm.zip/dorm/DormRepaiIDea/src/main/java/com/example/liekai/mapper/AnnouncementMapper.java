package com.example.liekai.mapper;

public interface AnnouncementMapper {
}
