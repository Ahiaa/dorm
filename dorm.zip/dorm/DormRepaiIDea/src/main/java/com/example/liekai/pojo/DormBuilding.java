package com.example.liekai.pojo;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

@Data
@TableName("dorm_building")
public class DormBuilding {
    @TableId(value = "building_id", type = IdType.AUTO)
    private Integer buildingId;

    @TableField("building_name")
    private String buildingName; // 楼栋名称

    @TableField("manager_id")
    private String managerId; // 楼栋管理员ID
}
