package com.example.liekai.service;


import com.example.liekai.pojo.Repairman;

public interface RepairmanService {

    Repairman login(String repairmanId, String password);
}

