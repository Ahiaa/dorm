package com.example.liekai.service;


import com.example.liekai.pojo.studentt;

public interface StudentService {

    boolean register(studentt student);

    studentt login(String studentId, String password);

    boolean isStudentIdAvailable(String studentId);
}

