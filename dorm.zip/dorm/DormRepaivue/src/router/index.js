
import { createRouter, createWebHistory } from 'vue-router'

// 布局组件
import StudentLayout from '@/views/student/StudentLayout.vue'
import AdminLayout from '@/views/admin/AdminLayout.vue'

// 创建路由
const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    // 登录页面
    {
      path: '/login',
      name: 'Login',
      component: () => import('@/views/Login.vue')
    },

    // 学生端
    {
      path: '/',
      component: StudentLayout,
      redirect: '/student/info',
      children: [
        {
          path: 'student/info',
          name: 'StudentInfo',
          component: () => import('@/views/student/StudentInfo.vue'),
          meta: { title: '个人信息' }
        },
        {
          path: 'student/repair',
          name: 'StudentRepair',
          component: () => import('@/views/student/Repair.vue'),
          meta: { title: '故障报修' }
        },
        {
          path: 'student/records',
          name: 'StudentRecords',
          component: () => import('@/views/student/Records.vue'),
          meta: { title: '报修记录' }
        },
        {
          path: 'student/avatar',
          name: 'StudentAvatar',
          component: () => import('@/views/student/UserAvtar.vue'),
          meta: { title: '修改头像' }
        },
            {
           path: 'student/avatar',  // 确保 avatar 路由正确配置
           component: () => import('@/views/student/UserAvtar.vue')  // 修正路径
       },
            {
           path: 'student/password',  
           component: () => import('@/views/student/Password.vue') 
       },
            {
           path: 'student/profile',  
           component: () => import('@/views/student/Profile.vue')  
       }
      ]
    },

    // 管理员端
    {
      path: '/admin',
      component: AdminLayout,
      redirect: '/admin/dashboard',
      children: [
        {
          path: 'dashboard',
          name: 'AdminDashboard',
          component: () => import('@/views/admin/Dashboard.vue'),
          meta: { title: '数据看板' }
        },
        {
          path: 'students',
          name: 'AdminStudents',
          component: () => import('@/views/admin/Students.vue'),
          meta: { title: '学生管理' }
        },
        {
          path: 'repairs',
          name: 'AdminRepairs',
          component: () => import('@/views/admin/Repairs.vue'),
          meta: { title: '报修管理' }
        },
        {
          path: 'dormitories',
          name: 'AdminDormitories',
          component: () => import('@/views/admin/Dormitories.vue'),
          meta: { title: '宿舍管理' }
        },
        {
          path: 'categories',
          name: 'AdminCategories',
          component: () => import('@/views/admin/Categories.vue'),
          meta: { title: '故障分类' }
        },
        {
          path: 'settings',
          name: 'AdminSettings',
          component: () => import('@/views/admin/Settings.vue'),
          meta: { title: '系统设置' }
        },
            {
           path: 'avatar',  // 确保 avatar 路由正确配置
           component: () => import('@/views/admin/AdminAvtar.vue')  // 修正路径
       }
      ]
    },

    // 404 页面
    {
      path: '/:pathMatch(.*)*',
      name: 'NotFound',
      component: () => import('@/views/NotFound.vue') // 可自定义404页面
    }
  ]
})

export default router
