<template>

 <router-view></router-view>
</template>

<script setup>
import UserAvtar from './views/student/UserAvtar.vue';


</script>

<style >

</style>