<template>
  <el-container class="layout-container" style="height: 750px">
    <!-- 左侧菜单 -->
    <el-aside width="200px" class="sidebar">
      <!-- 菜单内容区域 -->
      <el-scrollbar class="sidebar-scroll">
        <el-menu router class="sidebar-menu">
          <slot name="menu-items"></slot>
        </el-menu>
      </el-scrollbar>
    </el-aside>

    <!-- 主内容区域 -->
    <el-container>
      <!-- 头部 -->
      <el-header class="header">
        <div class="header-toolbar">
          <div class="system-title">宿舍报修系统</div>
          <el-dropdown @command="handleCommand" class="user-dropdown">
            <span class="dropdown-trigger">
              <el-avatar :src="avatarUrl" />
              <el-icon class="dropdown-icon">
                <CaretBottom />
              </el-icon>
            </span>
            <template #dropdown>
              <el-dropdown-menu>
                <el-dropdown-item command="logout" :icon="SwitchButton">
                  退出登录
                </el-dropdown-item>
                <el-dropdown-item :command="moreCommand" :icon="Crop">
                  更多
                </el-dropdown-item>
              </el-dropdown-menu>
            </template>
          </el-dropdown>
        </div>
      </el-header>

      <!-- 主内容 -->
      <el-main class="main-content">
        <div class="content-wrapper">
          <router-view />
        </div>
      </el-main>
    </el-container>
  </el-container>
</template>

<script lang="ts">
import { defineComponent } from 'vue'
import { useRouter } from 'vue-router'
import { useTokenStore } from '@/stores/token.js'
import { ElMessage, ElMessageBox } from 'element-plus'
import {
  SwitchButton,
  CaretBottom,
  Crop,
  House
} from '@element-plus/icons-vue'

export default defineComponent({
  name: 'BaseLayout',
  components: {
    SwitchButton,
    CaretBottom,
    Crop,
    House
  },
  props: {
    moreCommand: {
      type: String,
      default: 'avatar'
    }
  },
  setup(props) {
    const router = useRouter()
    const tokenStore = useTokenStore()

    const avatarUrl = 'https://big-001event.oss-cn-beijing.aliyuncs.com/7a0c69d2-84a5-45a1-8ce2-801ab1b98a76.jpg'

    const handleCommand = (command: string) => {
      if (command === 'logout') {
        handleLogout()
      } else {
        router.push('/' + command)
      }
    }

    const handleLogout = () => {
      ElMessageBox.confirm('您确认要退出吗?', '温馨提示', {
        confirmButtonText: '确认',
        cancelButtonText: '取消',
        type: 'warning',
      })
        .then(() => {
          tokenStore.removeToken()
          router.push('/login')
          ElMessage({
            type: 'success',
            message: '退出登录成功',
          })
        })
        .catch(() => {
          ElMessage({
            type: 'info',
            message: '您取消了退出登录',
          })
        })
    }

    return {
      avatarUrl,
      handleCommand,
      handleLogout
    }
  }
})
</script>

<style scoped lang="scss">
.layout-container {
  overflow: hidden;
  
  .header {
    position: relative;
    background-color: var(--el-color-primary-light-7);
    color: var(--el-text-color-primary);
    padding: 0 20px;
    display: flex;
    align-items: center;
    
    .header-toolbar {
      display: flex;
      align-items: center;
      justify-content: space-between;
      width: 100%;
      height: 100%;
      
      .system-title {
        font-size: 24px;
        font-weight: bold;
        color: #67c10a;
        flex-grow: 1;
        text-align: center;
      }
      
      .user-dropdown {
        .dropdown-trigger {
          display: flex;
          align-items: center;
          cursor: pointer;
          
          .dropdown-icon {
            color: #999;
            margin-left: 10px;
            transition: transform 0.3s ease;
          }
          
          &:hover .dropdown-icon {
            transform: rotate(180deg);
          }
          
          &:active,
          &:focus {
            outline: none;
          }
        }
      }
    }
  }

  .sidebar {
    color: var(--el-text-color-primary);
    background: var(--el-color-primary-light-8);
    overflow: hidden;
    display: flex;
    flex-direction: column;
    
    .sidebar-scroll {
      flex: 1;
      
      .sidebar-menu {
        border-right: none;
        
        .el-menu-item,
        .el-sub-menu {
          &:hover {
            background-color: var(--el-color-primary-light-9);
          }
        }
      }
    }
  }

  .main-content {
    padding: 0;
    overflow: hidden;
    background-color: var(--el-bg-color-page);
    
    .content-wrapper {
      height: 100%;
      overflow: hidden;
    }
  }
}

// 滚动条隐藏处理，避免 Sass 警告
.layout-container,
.layout-container *,
.layout-container *::before,
.layout-container *::after {
  scrollbar-width: none !important;
  -ms-overflow-style: none !important;

  &::-webkit-scrollbar {
    display: none !important;
    width: 0 !important;
    height: 0 !important;
  }
}

:deep(.el-scrollbar) {
  .el-scrollbar__bar {
    display: none !important;
  }
  
  .el-scrollbar__wrap {
    overflow: hidden !important;
  }
}

:deep(.el-main) {
  overflow: hidden !important;
}

:deep(.el-container) {
  overflow: hidden !important;
}
</style>
