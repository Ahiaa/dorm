<template>
<h1 >故障报修</h1>
</template>

<script setup>

</script>

<style lang="scss" scoped>

</style>