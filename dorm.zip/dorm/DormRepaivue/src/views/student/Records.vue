<template>
<h1 >报修记录</h1>
</template>

<script setup>

</script>

<style lang="scss" scoped>

</style>