<template>
<h1 >修改密码</h1>
</template>

<script setup>

</script>

<style lang="scss" scoped>

</style>