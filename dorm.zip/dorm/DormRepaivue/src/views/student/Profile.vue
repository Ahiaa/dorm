<template>
<h1 >个人信息</h1>
</template>

<script setup>

</script>

<style lang="scss" scoped>

</style>