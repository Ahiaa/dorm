<template>
<h1 >个人主页</h1>
</template>

<script setup>

</script>

<style lang="scss" scoped>

</style>