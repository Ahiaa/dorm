<template>
  <BaseLayout more-command="student/avatar">
    <template #menu-items>
            <!-- 添加宿舍报修标题 -->
      <div class="menu-title">
        <i class="title-icon">🏠</i>
        <span>宿舍报修系统</span>
      </div>

      <el-menu-item index="/student/repair">
        <el-icon>
          <Tools />
        </el-icon>
        <span>故障报修</span>
      </el-menu-item>

      <el-menu-item index="/student/records">
        <el-icon>
          <List />
        </el-icon>
        <span>报修记录</span>
      </el-menu-item>

      <el-sub-menu index="1">
        <template #title>
          <el-icon><User /></el-icon>
          <span>个人中心</span>
        </template>
        <el-menu-item index="/student/profile">个人信息</el-menu-item>
        <el-menu-item index="/student/password">修改密码</el-menu-item>
      </el-sub-menu>
    </template>
  </BaseLayout>
</template>

<script lang="ts">
import { defineComponent } from 'vue'
import BaseLayout from '@/views/BaseLayout.vue'
import { Tools, List, User } from '@element-plus/icons-vue'

export default defineComponent({
  name: 'StudentLayout',
  components: {
    BaseLayout,
    // 注册图标组件
    Tools,
    List,
    User
  }
})
</script>
<style scoped lang="scss">
.menu-title {
  display: flex;
  align-items: center;
  padding: 16px 20px;
  font-size: 14px;
  font-weight: bold;
  color: var(--el-text-color-primary);
  background-color: var(--el-color-primary-light-9);
  border-bottom: 1px solid var(--el-border-color-lighter);
  margin-bottom: 8px;

  .title-icon {
    margin-right: 8px;
    font-size: 18px;
    color: var(--el-color-primary);
  }

  span {
    font-size: 16px;
    color: var(--el-color-primary);
  }
}
</style>