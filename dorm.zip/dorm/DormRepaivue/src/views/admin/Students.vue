<template>
<h1 >学生管理</h1>
</template>

<script setup>

</script>

<style lang="scss" scoped>

</style>