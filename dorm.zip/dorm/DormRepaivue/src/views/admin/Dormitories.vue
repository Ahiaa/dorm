<template>
<h1 >宿舍管理</h1>
</template>

<script setup>

</script>

<style lang="scss" scoped>

</style>