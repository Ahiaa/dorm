<template>
  <BaseLayout more-command="admin/avatar">
    <template #menu-items>
      <!-- 添加宿舍报修标题 -->
      <div class="menu-title">
        <i class="title-icon">🏠</i>
        <span>宿舍报修系统</span>
      </div>

      <el-menu-item index="/admin/dashboard">
        <el-icon>
          <DataBoard />
        </el-icon>
        <span>数据看板</span>
      </el-menu-item>

      <el-menu-item index="/admin/students">
        <el-icon>
          <User />
        </el-icon>
        <span>学生管理</span>
      </el-menu-item>

      <el-menu-item index="/admin/repairs">
        <el-icon>
          <Tools />
        </el-icon>
        <span>报修管理</span>
      </el-menu-item>

      <el-menu-item index="/admin/dormitories">
        <el-icon>
          <House />
        </el-icon>
        <span>宿舍管理</span>
      </el-menu-item>

      <el-sub-menu index="1">
        <template #title>
          <el-icon><Setting /></el-icon>
          <span>系统管理</span>
        </template>
        <el-menu-item index="/admin/categories">故障分类</el-menu-item>
        <el-menu-item index="/admin/settings">系统设置</el-menu-item>
      </el-sub-menu>
    </template>
  </BaseLayout>
</template>

<script lang="ts">
import { defineComponent } from 'vue';
import BaseLayout from '@/views/BaseLayout.vue';
import { DataBoard, User, Tools, House, Setting } from '@element-plus/icons-vue';

export default defineComponent({
  name: 'AdminLayout',
  components: {
    BaseLayout,
    DataBoard,
    User,
    Tools,
    House,
    Setting,
  },
});
</script>

<style scoped lang="scss">
.menu-title {
  display: flex;
  align-items: center;
  padding: 16px 20px;
  font-size: 14px;
  font-weight: bold;
  color: var(--el-text-color-primary);
  background-color: var(--el-color-primary-light-9);
  border-bottom: 1px solid var(--el-border-color-lighter);
  margin-bottom: 8px;

  .title-icon {
    margin-right: 8px;
    font-size: 18px;
    color: var(--el-color-primary);
  }

  span {
    font-size: 16px;
    color: var(--el-color-primary);
  }
}
</style>
