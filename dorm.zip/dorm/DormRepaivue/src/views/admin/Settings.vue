<template>
<h1 >系统设置</h1>
</template>

<script setup>

</script>

<style lang="scss" scoped>

</style>