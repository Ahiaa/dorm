<template>
<h1 >故障分类</h1>
</template>

<script setup>

</script>

<style lang="scss" scoped>

</style>