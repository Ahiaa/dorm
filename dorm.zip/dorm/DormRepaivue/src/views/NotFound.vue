<template>
  <div class="error-container">
    <div class="error-content">
      <h1 class="error-code">{{ code }}</h1>
      <p class="error-message">{{ message }}</p>
      <el-button type="primary" @click="goHome">返回首页</el-button>
    </div>
  </div>
</template>

<script setup lang="ts">
import { useRouter } from 'vue-router'
import { ElButton } from 'element-plus'

interface Props {
  code?: string
  message?: string
}

const props = withDefaults(defineProps<Props>(), {
  code: '404',
  message: '页面找不到了~'
})

const router = useRouter()

const goHome = () => {
  router.push('/')
}
</script>

<style scoped lang="scss">
.error-container {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
  background: var(--el-bg-color-page);
}

.error-content {
  text-align: center;

  .error-code {
    font-size: 120px;
    color: var(--el-color-primary);
    margin-bottom: 20px;
  }

  .error-message {
    font-size: 20px;
    color: #999;
    margin-bottom: 30px;
  }

  .el-button {
    padding: 10px 30px;
  }
}
</style>
