<template>
  <div class="login-container">
    <div class="login-box">
      <!-- 右侧表单 -->
      <div class="login-form">
        <!-- 注册表单 -->
        <el-form
          ref="form"
          size="large"
          v-if="isRegister"
          :model="registerData"
          :rules="rules"
          class="register-form"
        >
          <h2 class="title register-title">学生注册</h2>
          
          <el-form-item prop="studentId" class="form-item-compact">
            <el-input
              :prefix-icon="User"
              placeholder="请输入学号"
              v-model="registerData.studentId"
              @blur="checkStudentIdAvailable"
            />
          </el-form-item>

          <el-form-item prop="name" class="form-item-compact">
            <el-input
              :prefix-icon="User"
              placeholder="请输入姓名"
              v-model="registerData.name"
            />
          </el-form-item>

          <el-form-item prop="phone" class="form-item-compact">
            <el-input
              :prefix-icon="User" 
              placeholder="请输入手机号"
              v-model="registerData.phone"
            />
          </el-form-item>

          <el-form-item prop="buildingId" class="form-item-compact">
            <el-select
              v-model="registerData.buildingId"
              placeholder="请选择宿舍楼"
              style="width: 100%"
            >
              <el-option label="1号楼" value="1" />
              <el-option label="2号楼" value="2" />
              <el-option label="3号楼" value="3" />
              <el-option label="4号楼" value="4" />
              <el-option label="5号楼" value="5" />
            </el-select>
          </el-form-item>

          <el-form-item prop="dormNumber" class="form-item-compact">
            <el-input
              placeholder="请输入宿舍号"
              v-model="registerData.dormNumber"
            />
          </el-form-item>

          <el-form-item prop="password" class="form-item-compact">
            <el-input
              :prefix-icon="Lock"
              type="password" 
              placeholder="请输入密码"
              v-model="registerData.password"
              show-password
            />
          </el-form-item>

          <el-form-item prop="rePassword" class="form-item-compact">
            <el-input
              :prefix-icon="Lock"
              type="password"
              placeholder="请确认密码" 
              v-model="registerData.rePassword"
              show-password
            />
          </el-form-item>

          <el-form-item class="form-item-compact submit-item">
            <el-button type="primary" class="submit-btn" @click="register">
              注册
            </el-button>
          </el-form-item>

          <div class="form-footer register-footer">
            <span>已有账号?</span>
            <el-link type="primary" @click="isRegister = false; clearRegisterData()">
              去登录
            </el-link>
          </div>
        </el-form>

        <!-- 登录表单 -->
        <el-form
          ref="form"
          size="large" 
          v-else
          :model="loginData"
          class="login-form-inner"
        >
          <h2 class="title">登录</h2>
         
          <!-- 角色选择 -->
          <el-form-item>
            <el-select v-model="loginData.role" placeholder="请选择角色" style="width: 100%" @change="handleRoleChange">
              <el-option label="学生登录" value="student" />
              <el-option label="管理员登录" value="admin" />
            </el-select>
          </el-form-item>

          <el-form-item>
            <el-input
              :prefix-icon="User"
              :placeholder="loginData.role === 'admin' ? '请输入管理员ID' : '请输入学号'"
              v-model="loginData.account"
            />
          </el-form-item>

          <el-form-item>
            <el-input
              :prefix-icon="Lock"
              type="password"
              placeholder="请输入密码"
              v-model="loginData.password"
              show-password
            />
          </el-form-item>

          <div class="remember-forgot">
            <el-checkbox v-model="rememberMe">记住我</el-checkbox>
            <el-link type="primary">忘记密码?</el-link>
          </div>

          <el-form-item>
            <el-button type="primary" class="submit-btn" @click="login">
              登录
            </el-button>
          </el-form-item>

          <div class="form-footer">
            <span>没有账号?</span>
            <el-link type="primary" @click="isRegister = true; clearRegisterData()">
              立即注册
            </el-link>
          </div>
        </el-form>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive } from 'vue'
import { User, Lock } from '@element-plus/icons-vue'
import { ElMessage } from 'element-plus'
import { studentRegisterService, studentLoginService, checkStudentIdService } from '@/api/student.js'
import { useRouter } from 'vue-router'
import { useTokenStore } from '@/stores/token.js'
import { adminLoginService } from '@/api/admin.js'

const router = useRouter()
const tokenStore = useTokenStore()

const isRegister = ref(false)
const rememberMe = ref(false)
const form = ref()

// 注册数据
const registerData = reactive({
  studentId: '',
  name: '',
  phone: '',
  buildingId: '',
  dormNumber: '',
  password: '',
  rePassword: ''
})

// 登录数据 - 分离出来
const loginData = reactive({
  role: 'student',
  account: '', // 统一的账号字段，学生用学号，管理员用adminId
  password: ''
})

const rules = {
  studentId: [
    { required: true, message: '请输入学号', trigger: 'blur' },
    { min: 11, max: 11, message: '学号长度应为11位', trigger: 'blur' }
  ],
  name: [
    { required: true, message: '请输入姓名', trigger: 'blur' },
    { min: 2, max: 10, message: '姓名长度应为2-10位', trigger: 'blur' }
  ],
  phone: [
    { required: true, message: '请输入手机号', trigger: 'blur' },
    { pattern: /^1[3-9]\d{9}$/, message: '请输入正确的手机号', trigger: 'blur' }
  ],
  buildingId: [
    { required: true, message: '请选择宿舍楼', trigger: 'change' }
  ],
  dormNumber: [
    { required: true, message: '请输入宿舍号', trigger: 'blur' },
    { pattern: /^\d{3,4}$/, message: '宿舍号应为3-4位数字', trigger: 'blur' }
  ],
  password: [
    { required: true, message: '请输入密码', trigger: 'blur' },
    { min: 6, max: 20, message: '密码长度应为6-20位', trigger: 'blur' }
  ],
  rePassword: [
    { required: true, message: '请确认密码', trigger: 'blur' },
    {
      validator: (rule, value, callback) => {
        if (value !== registerData.password) {
          callback(new Error('两次输入的密码不一致'))
        } else {
          callback()
        }
      },
      trigger: 'blur'
    }
  ]
}

const checkStudentIdAvailable = async () => {
  if (!registerData.studentId) return
  
  try {
    const result = await checkStudentIdService(registerData.studentId)
    if (!result.data.available) {
      ElMessage.warning('该学号已被注册')
    }
  } catch (error) {
    console.log('检查学号可用性失败:', error)
  }
}

const register = async () => {
  await form.value.validate()
  
  try {
    await studentRegisterService(registerData)
    ElMessage.success('注册成功，请登录')
    isRegister.value = false
    clearRegisterData()
  } catch (error) {
    ElMessage.error(error.response?.data?.msg || '注册失败')
  }
}

const login = async () => {
  // 简单的必填验证
  if (!loginData.role) {
    ElMessage.warning('请选择角色')
    return
  }
  
  if (!loginData.account) {
    ElMessage.warning(loginData.role === 'admin' ? '请输入管理员ID' : '请输入学号')
    return
  }
  
  if (!loginData.password) {
    ElMessage.warning('请输入密码')
    return
  }

  try {
    if (loginData.role === 'student') {
      const result = await studentLoginService(loginData.account, loginData.password)
      tokenStore.setToken(result.data)
      ElMessage.success('学生登录成功')
      router.push('/')
    } else if (loginData.role === 'admin') {
      const result = await adminLoginService(loginData.account, loginData.password)
      tokenStore.setToken(result.data)
      ElMessage.success('管理员登录成功')
      router.push('/admin/dashboard')
    }
  } catch (error) {
   
  }
}

// 角色切换时清空账号输入
const handleRoleChange = () => {
  loginData.account = '',
  loginData.password=''
}

const clearRegisterData = () => {
  Object.keys(registerData).forEach(key => {
    registerData[key] = ''
  })
  // 清空登录数据
  loginData.role = 'student'
  loginData.account = ''
  loginData.password = ''
  form.value?.clearValidate()
}
</script>

<style lang="scss" scoped>
.login-container {
  min-height: 100vh;
  background-color: #f5f7f9;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 20px;
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  overflow-y: auto;

  .login-box {
    width: 450px;
    max-width: 95%;
    background-color: white;
    border-radius: 16px;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
    margin: auto;
    
    @media (max-width: 576px) {
      width: 90%;
    }

    .login-form {
      width: 80%;
      padding: 40px;
      display: flex;
      flex-direction: column;
      justify-content: center;
      
      @media (max-width: 576px) {
        padding: 30px 20px;
      }

      // 注册表单样式
      .register-form {
        padding-top: 10px !important;
        padding-bottom: 10px !important;
        justify-content: flex-start !important;
        
        .register-title {
          margin-bottom: 16px !important;
          font-size: 24px !important;
        }
        
        .form-item-compact {
          margin-bottom: 16px !important;
          
          :deep(.el-form-item__error) {
            position: static !important;
            margin-top: 4px !important;
            line-height: 1.2 !important;
            font-size: 12px !important;
          }
        }
        
        .submit-item {
          margin-bottom: 8px !important;
        }
        
        .register-footer {
          margin-top: 8px !important;
        }
      }

      // 登录表单保持原样
      .login-form-inner {
        padding: 0;
      }

      .title {
        font-size: 28px;
        font-weight: 600;
        color: #67c10a;
        margin-bottom: 40px;
        text-align: center;
        
        @media (max-width: 576px) {
          font-size: 24px;
          margin-bottom: 30px;
        }
      }

      :deep(.el-input) {
        .el-input__wrapper {
          box-shadow: 0 0 0 1px #dcdfe6 inset;
          height: 44px;
          
          &:hover {
            box-shadow: 0 0 0 1px #67c23a inset;
          }
          
          &.is-focus {
            box-shadow: 0 0 0 1px #67c23a inset;
          }
        }
      }

      :deep(.el-select) {
        .el-select__wrapper {
          box-shadow: 0 0 0 1px #dcdfe6 inset;
          height: 44px;
          
          &:hover {
            box-shadow: 0 0 0 1px #67c23a inset;
          }
          
          &.is-focus {
            box-shadow: 0 0 0 1px #67c23a inset;
          }
        }
      }

      .submit-btn {
        width: 100%;
        height: 44px;
        border-radius: 22px;
        font-size: 16px;
        margin-top: 20px;
      }

      .remember-forgot {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin: -10px 0 10px;
        font-size: 14px;
      }

      .form-footer {
        text-align: center;
        margin-top: 20px;
        color: #999;
        font-size: 14px;

        .el-link {
          margin-left: 8px;
        }
      }
    }
  }
}

// 注册表单在小屏幕上的额外优化
@media (max-height: 700px) {
  .login-container .login-box .login-form .register-form {
    .register-title {
      font-size: 22px !important;
      margin-bottom: 12px !important;
    }
    
    .form-item-compact {
      margin-bottom: 12px !important;
    }
  }
}
</style>