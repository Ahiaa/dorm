import request from '@/utils/request.js'

// 学生注册
export const studentRegisterService = (student) => {
    return request.post('/api/student/register', student)
}

// 学生登录
export const studentLoginService = (studentId, password) => {
    return request.post('/api/student/login', null, {
        params: {
            studentId,
            password
        }
    })
}

// 检查学号是否可用
export const checkStudentIdService = (studentId) => {
    return request.get('/api/student/check-id', {
        params: {
            studentId
        }
    })
}