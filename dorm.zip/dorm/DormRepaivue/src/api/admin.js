import request from '@/utils/request.js'
export const adminLoginService = (adminId, password) => {
  return request.post('/api/admin/login', null, {
    params: {
      adminId,
      password
    }
  })
}

